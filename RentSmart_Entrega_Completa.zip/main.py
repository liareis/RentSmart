"""
Módulo Principal do RentSmart - Ponto de Entrada do Sistema
"""
 
import sys
import os
from calculadora import CalculadoraRentSmart
from relatorio import GeradorRelatorio
 
 
def solicitar_entrada_validada(mensagem_prompt: str, funcao_validacao):
    """Solicita entrada do usuário iterativamente até receber um valor válido."""
    while True:
        try:
            entrada = input(mensagem_prompt)
            return funcao_validacao(entrada)
        except ValueError as err:
            print(f"  [ERRO] {err} Tente novamente.\n")
 
 
def executar_cenario_demonstracao():
    """Executa o cenário oficial de demonstração para testes e avaliação."""
    print("\n" + "=" * 65)
    print("      EXECUTANDO CENÁRIO DE DEMONSTRAÇÃO OFICIAL (RENTSMART)     ")
    print("=" * 65)
    print("Cenário: Apartamento 2 quartos, Sem crianças, Com garagem, Taxa em 5x.\n")
    
    orcamento = CalculadoraRentSmart.criar_orcamento(
        nome_cliente="Cliente Demonstração",
        categoria="Apartamento",
        quartos=2,
        tem_criancas=False,
        possui_garagem=True,
        vagas_estudio=0,
        parcelas_taxa=5
    )
 
    GeradorRelatorio.exibir_orcamento_detalhado(orcamento)
    caminho_csv = GeradorRelatorio.gerar_csv_12_meses(orcamento, "orcamento_12_meses.csv")
    print(f"[SUCESSO] Relatório de 12 meses gerado em: {caminho_csv}\n")
    return orcamento
 
 
def menu_interativo():
    """Menu interativo para coleta de dados do cliente e cálculo dinâmico."""
    print("=" * 65)
    print("         BEM-VINDO AO RENTSMART - ORÇAMENTO DE LOCAÇÃO         ")
    print("=" * 65)
    
    nome = input("Digite o nome do cliente: ").strip()
    if not nome:
        nome = "Cliente Não Identificado"
 
    print("\nSelecione a Categoria do Imóvel:")
    print(" 1 - Apartamento")
    print(" 2 - Casa")
    print(" 3 - Estúdio")
    categoria = solicitar_entrada_validada(
        "Opção (1, 2 ou 3): ", 
        CalculadoraRentSmart.validar_categoria
    )
 
    quartos = 1
    possui_garagem = False
    vagas_estudio = 0
 
    if categoria in ["Apartamento", "Casa"]:
        quartos = solicitar_entrada_validada(
            "Quantidade de quartos (1 ou 2): ",
            CalculadoraRentSmart.validar_quartos
        )
        possui_garagem = solicitar_entrada_validada(
            "Possui vaga de garagem? (S/N): ",
            CalculadoraRentSmart.validar_sim_nao
        )
    elif categoria == "Estúdio":
        vagas_estudio = solicitar_entrada_validada(
            "Quantidade de vagas de estacionamento desejadas: ",
            CalculadoraRentSmart.validar_vagas_estudio
        )
 
    tem_criancas = solicitar_entrada_validada(
        "O cliente possui crianças no imóvel? (S/N): ",
        CalculadoraRentSmart.validar_sim_nao
    )
 
    parcelas_taxa = solicitar_entrada_validada(
        "Em quantas parcelas deseja pagar a Taxa Contratual (1 a 5)? ",
        CalculadoraRentSmart.validar_parcelas_taxa
    )
 
    orcamento = CalculadoraRentSmart.criar_orcamento(
        nome_cliente=nome,
        categoria=categoria,
        quartos=quartos,
        tem_criancas=tem_criancas,
        possui_garagem=possui_garagem,
        vagas_estudio=vagas_estudio,
        parcelas_taxa=parcelas_taxa
    )
 
    GeradorRelatorio.exibir_orcamento_detalhado(orcamento)
    caminho_csv = GeradorRelatorio.gerar_csv_12_meses(orcamento, "orcamento_12_meses.csv")
    print(f"[SUCESSO] Relatório de 12 meses gerado em: {caminho_csv}\n")
 
 
if __name__ == "__main__":
    if "--demo" in sys.argv:
        executar_cenario_demonstracao()
    else:
        print("Opções de Execução:")
        print(" 1 - Iniciar Orçamento Interativo (Entrada via Teclado)")
        print(" 2 - Executar Cenário de Demonstração Oficial (Apartamento 2Q, Garagem, Sem Crianças, 5x)")
        opcao = input("Escolha a opção (1 ou 2, padrão 1): ").strip()
        if opcao == "2":
            executar_cenario_demonstracao()
        else:
            menu_interativo()
