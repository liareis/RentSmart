"""
Módulo Relatório do RentSmart
Responsável pela exibição do orçamento formatado no terminal e pela exportação do relatório CSV de 12 meses.
"""
 
import csv
import os
from decimal import Decimal
from modelos import OrcamentoLocacao
 
 
class GeradorRelatorio:
    """Gerencia a saída de dados no console e a gravação do arquivo CSV de 12 meses."""
 
    @staticmethod
    def formatar_moeda(valor: Decimal) -> str:
        """Formata um valor Decimal no padrão monetário brasileiro R$ 1.234,56."""
        v_str = f"{valor:,.2f}"
        v_br = v_str.replace(",", "X").replace(".", ",").replace("X", ".")
        return f"R$ {v_br}"
 
    @classmethod
    def exibir_orcamento_detalhado(cls, orcamento: OrcamentoLocacao) -> None:
        """Exibe o resumo financeiro completo no terminal."""
        cliente = orcamento.cliente
        imovel = orcamento.imovel
 
        print("\n" + "=" * 65)
        print("           RENTSMART - ORÇAMENTO DETALHADO DE LOCAÇÃO          ")
        print("=" * 65)
        print(f" Cliente                : {cliente.nome}")
        print(f" Perfil Familiar        : {'Com crianças' if cliente.tem_criancas else 'Sem crianças'}")
        print("-" * 65)
        print(f" Categoria do Imóvel    : {imovel.categoria}")
        
        if imovel.categoria != "Estúdio":
            print(f" Quantidade de Quartos  : {imovel.quartos} quarto(s)")
            print(f" Garagem / Estacionamento: {'Sim' if getattr(imovel, 'possui_garagem', False) else 'Não'}")
        else:
            print(f" Vagas de Estacionamento: {getattr(imovel, 'quantidade_vagas', 0)} vaga(s)")
 
        print("-" * 65)
        print(f" Aluguel-Base           : {cls.formatar_moeda(orcamento.base)}")
        print(f" Adicional de Quartos   : {cls.formatar_moeda(orcamento.adic_quartos)}")
        print(f" Adicional Garagem/Vagas: {cls.formatar_moeda(orcamento.adic_garagem)}")
        print(f" Desconto Elegível      : -{cls.formatar_moeda(orcamento.desconto)}")
        print(f" --> ALUGUEL MENSAL FINAL: {cls.formatar_moeda(orcamento.aluguel_mensal)}")
        print("-" * 65)
        print(f" Taxa Contratual Total  : {cls.formatar_moeda(orcamento.TAXA_CONTRATUAL_TOTAL)}")
        print(f" Parcelamento da Taxa   : {orcamento.parcelas_taxa}x (1ª Parcela: {cls.formatar_moeda(orcamento.valor_primeira_parcela_taxa)})")
        print("-" * 65)
        print(f" TOTAL NO PRIMEIRO MÊS  : {cls.formatar_moeda(orcamento.total_primeiro_mes)}")
        print(f" TOTAL PREVISTO (12 MESES): {cls.formatar_moeda(orcamento.total_previsto_12_meses)}")
        print("=" * 65 + "\n")
 
    @classmethod
    def gerar_csv_12_meses(cls, orcamento: OrcamentoLocacao, caminho_arquivo: str = "orcamento_12_meses.csv") -> str:
        """
        Exporta a projeção dos 12 meses em arquivo CSV formatado para Excel (separador ';', UTF-8 com BOM).
        """
        fluxo = orcamento.obter_fluxo_12_meses()
 
        cabeçalhos = [
            "Mês",
            "Categoria Imóvel",
            "Aluguel Mensal (R$)",
            "Parcela Taxa Contratual (R$)",
            "Total Previsto do Mês (R$)"
        ]
 
        diretorio = os.path.dirname(caminho_arquivo)
        if diretorio and not os.path.exists(diretorio):
            os.makedirs(diretorio, exist_ok=True)
 
        with open(caminho_arquivo, mode="w", newline="", encoding="utf-8-sig") as f:
            escritor = csv.writer(f, delimiter=";")
            escritor.writerow(cabeçalhos)
 
            for item in fluxo:
                escritor.writerow([
                    f"Mês {item['mes']}",
                    orcamento.imovel.categoria,
                    f"{item['aluguel_mensal']:.2f}".replace(".", ","),
                    f"{item['parcela_taxa']:.2f}".replace(".", ","),
                    f"{item['total_mes']:.2f}".replace(".", ",")
                ])
 
        return os.path.abspath(caminho_arquivo)
