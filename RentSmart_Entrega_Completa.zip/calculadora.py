"""
Módulo Calculadora do RentSmart
Encapsula as funções de validação de dados de entrada e construção de instâncias.
"""
 
from decimal import Decimal
from modelos import Cliente, Imovel, Apartamento, Casa, Estudio, OrcamentoLocacao
 
 
class CalculadoraRentSmart:
    """Camada de serviço e fábrica de objetos com validação rigorosa de dados."""
 
    @staticmethod
    def validar_categoria(opcao: str) -> str:
        categorias = {"1": "Apartamento", "2": "Casa", "3": "Estúdio"}
        opcao_clean = opcao.strip()
        if opcao_clean in categorias:
            return categorias[opcao_clean]
        raise ValueError("Opção de categoria inválida! Escolha 1 (Apartamento), 2 (Casa) ou 3 (Estúdio).")
 
    @staticmethod
    def validar_quartos(valor_str: str) -> int:
        valor_clean = valor_str.strip()
        if valor_clean in ["1", "2"]:
            return int(valor_clean)
        raise ValueError("Quantidade de quartos inválida! Digite 1 ou 2.")
 
    @staticmethod
    def validar_sim_nao(resposta_str: str) -> bool:
        resp = resposta_str.strip().lower()
        if resp in ["s", "sim", "1"]:
            return True
        if resp in ["n", "nao", "não", "2"]:
            return False
        raise ValueError("Resposta inválida! Digite 'S' para Sim ou 'N' para Não.")
 
    @staticmethod
    def validar_vagas_estudio(vagas_str: str) -> int:
        try:
            vagas = int(vagas_str.strip())
            if vagas >= 0:
                return vagas
            raise ValueError()
        except ValueError:
            raise ValueError("Quantidade de vagas inválida! Digite um número inteiro maior ou igual a zero.")
 
    @staticmethod
    def validar_parcelas_taxa(parcelas_str: str) -> int:
        try:
            p = int(parcelas_str.strip())
            if 1 <= p <= 5:
                return p
            raise ValueError()
        except ValueError:
            raise ValueError("Número de parcelas inválido! Escolha um valor entre 1 e 5.")
 
    @classmethod
    def criar_orcamento(
        cls,
        nome_cliente: str,
        categoria: str,
        quartos: int,
        tem_criancas: bool,
        possui_garagem: bool,
        vagas_estudio: int,
        parcelas_taxa: int
    ) -> OrcamentoLocacao:
        cliente = Cliente(nome=nome_cliente, tem_criancas=tem_criancas)
 
        if categoria == "Apartamento":
            imovel = Apartamento(quartos=quartos, possui_garagem=possui_garagem)
        elif categoria == "Casa":
            imovel = Casa(quartos=quartos, possui_garagem=possui_garagem)
        elif categoria == "Estúdio":
            imovel = Estudio(quantidade_vagas=vagas_estudio)
        else:
            raise ValueError(f"Categoria desconhecida: {categoria}")
 
        return OrcamentoLocacao(cliente=cliente, imovel=imovel, parcelas_taxa=parcelas_taxa)
