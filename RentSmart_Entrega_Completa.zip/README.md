# RentSmart — Orçamento de Locação

Aplicação em Python para calcular orçamento de locação de apartamento, casa ou estúdio e gerar uma projeção de pagamentos de 12 meses em CSV.

## Requisitos
- Python 3.10 ou superior (não utiliza bibliotecas externas).

## Como executar
1. Extraia os arquivos para uma mesma pasta.
2. Abra um terminal nessa pasta.
3. Execute o modo interativo:

   ```bash
   python main.py
   ```

4. Para executar o cenário de demonstração:

   ```bash
   python main.py --demo
   ```

O arquivo `orcamento_12_meses.csv` será criado na pasta de execução e poderá ser aberto no Excel.

## Arquivos
- `main.py`: ponto de entrada e interação com o usuário.
- `modelos.py`: classes Cliente, Imovel, Apartamento, Casa, Estudio e OrcamentoLocacao.
- `calculadora.py`: valida entradas e cria os objetos do orçamento.
- `relatorio.py`: exibe o orçamento e exporta o CSV.

## Regras implementadas
- Apartamento: aluguel-base de R$ 700,00; segundo quarto + R$ 200,00; garagem + R$ 300,00.
- Casa: aluguel-base de R$ 900,00; segundo quarto + R$ 250,00; garagem + R$ 300,00.
- Estúdio: aluguel-base de R$ 1.200,00; pacote de estacionamento de R$ 250,00 para até duas vagas; cada vaga adicional custa R$ 60,00.
- Apartamento sem crianças: desconto de 5% sobre o aluguel-base e os adicionais.
- Taxa contratual total: R$ 2.000,00, parcelada em 1 a 5 vezes.

## Observação
Confirme as regras acima com o enunciado oficial antes de entregar. O projeto não depende de `requirements.txt`, pois utiliza apenas a biblioteca padrão do Python.
