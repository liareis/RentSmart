"""
Módulo de Modelos do RentSmart - Programação Orientada a Objetos (POO)
Contém as classes que representam o Cliente, as categorias de Imóvel e o Orçamento de Locação.
"""
 
from abc import ABC, abstractmethod
from decimal import Decimal, ROUND_HALF_UP
 
 
class Cliente:
    """Representa o cliente com informações do perfil familiar (presença de crianças)."""
    
    def __init__(self, nome: str, tem_criancas: bool):
        self._nome = nome.strip() if nome else "Cliente Não Identificado"
        self._tem_criancas = tem_criancas
 
    @property
    def nome(self) -> str:
        return self._nome
 
    @property
    def tem_criancas(self) -> bool:
        return self._tem_criancas
 
    def __str__(self) -> str:
        criancas_str = "Com crianças" if self._tem_criancas else "Sem crianças"
        return f"Cliente: {self._nome} ({criancas_str})"
 
 
class Imovel(ABC):
    """Classe abstrata base para os tipos de imóveis do sistema."""
 
    def __init__(self, categoria: str, base_aluguel: Decimal, quartos: int = 1):
        self._categoria = categoria
        self._base_aluguel = Decimal(str(base_aluguel))
        self._quartos = quartos
 
    @property
    def categoria(self) -> str:
        return self._categoria
 
    @property
    def base_aluguel(self) -> Decimal:
        return self._base_aluguel
 
    @property
    def quartos(self) -> int:
        return self._quartos
 
    @abstractmethod
    def calcular_adicional_quartos(self) -> Decimal:
        """Calcula o valor adicional recorrente pela quantidade de quartos."""
        pass
 
    @abstractmethod
    def calcular_adicional_garagem(self) -> Decimal:
        """Calcula o valor adicional recorrente por garagem ou vagas de estacionamento."""
        pass
 
    @abstractmethod
    def calcular_desconto(self, tem_criancas: bool, subtotal: Decimal) -> Decimal:
        """Calcula o valor do desconto elegível conforme as regras do imóvel."""
        pass
 
    def calcular_aluguel_mensal(self, tem_criancas: bool) -> tuple[Decimal, Decimal, Decimal, Decimal, Decimal]:
        """
        Calcula os componentes do aluguel mensal.
        Retorna: (base_aluguel, adic_quartos, adic_garagem, desconto, aluguel_mensal_final)
        """
        adic_q = self.calcular_adicional_quartos()
        adic_g = self.calcular_adicional_garagem()
        subtotal = self._base_aluguel + adic_q + adic_g
        desc = self.calcular_desconto(tem_criancas, subtotal)
        aluguel_final = subtotal - desc
        return (self._base_aluguel, adic_q, adic_g, desc, aluguel_final)
 
 
class Apartamento(Imovel):
    """Representa a categoria Apartamento."""
 
    def __init__(self, quartos: int, possui_garagem: bool):
        super().__init__(categoria="Apartamento", base_aluguel=Decimal("700.00"), quartos=quartos)
        self._possui_garagem = possui_garagem
 
    @property
    def possui_garagem(self) -> bool:
        return self._possui_garagem
 
    def calcular_adicional_quartos(self) -> Decimal:
        return Decimal("200.00") if self._quartos == 2 else Decimal("0.00")
 
    def calcular_adicional_garagem(self) -> Decimal:
        return Decimal("300.00") if self._possui_garagem else Decimal("0.00")
 
    def calcular_desconto(self, tem_criancas: bool, subtotal: Decimal) -> Decimal:
        # Desconto de 5% sobre a soma (base + adicionais) se NÃO houver crianças
        if not tem_criancas:
            return (subtotal * Decimal("0.05")).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        return Decimal("0.00")
 
 
class Casa(Imovel):
    """Representa a categoria Casa."""
 
    def __init__(self, quartos: int, possui_garagem: bool):
        super().__init__(categoria="Casa", base_aluguel=Decimal("900.00"), quartos=quartos)
        self._possui_garagem = possui_garagem
 
    @property
    def possui_garagem(self) -> bool:
        return self._possui_garagem
 
    def calcular_adicional_quartos(self) -> Decimal:
        return Decimal("250.00") if self._quartos == 2 else Decimal("0.00")
 
    def calcular_adicional_garagem(self) -> Decimal:
        return Decimal("300.00") if self._possui_garagem else Decimal("0.00")
 
    def calcular_desconto(self, tem_criancas: bool, subtotal: Decimal) -> Decimal:
        # Casas não possuem desconto por ausência de crianças
        return Decimal("0.00")
 
 
class Estudio(Imovel):
    """Representa a categoria Estúdio (fixo em 1 quarto)."""
 
    def __init__(self, quantidade_vagas: int = 0):
        super().__init__(categoria="Estúdio", base_aluguel=Decimal("1200.00"), quartos=1)
        self._quantidade_vagas = max(0, quantidade_vagas)
 
    @property
    def quantidade_vagas(self) -> int:
        return self._quantidade_vagas
 
    def calcular_adicional_quartos(self) -> Decimal:
        return Decimal("0.00")
 
    def calcular_adicional_garagem(self) -> Decimal:
        if self._quantidade_vagas > 0:
            # Pacote inicial de até 2 vagas por R$ 250,00 e adicionais por R$ 60,00 cada
            vagas_extras = max(0, self._quantidade_vagas - 2)
            return Decimal("250.00") + (Decimal(str(vagas_extras)) * Decimal("60.00"))
        return Decimal("0.00")
 
    def calcular_desconto(self, tem_criancas: bool, subtotal: Decimal) -> Decimal:
        # Estúdios não possuem desconto por ausência de crianças
        return Decimal("0.00")
 
 
class OrcamentoLocacao:
    """Classe agregadora que consolida Cliente, Imóvel e Parcelamento da Taxa Contratual."""
 
    TAXA_CONTRATUAL_TOTAL = Decimal("2000.00")
 
    def __init__(self, cliente: Cliente, imovel: Imovel, parcelas_taxa: int):
        if not (1 <= parcelas_taxa <= 5):
            raise ValueError("O número de parcelas da taxa contratual deve ser entre 1 e 5.")
        
        self._cliente = cliente
        self._imovel = imovel
        self._parcelas_taxa = parcelas_taxa
 
        # Cálculo do aluguel mensal e seus componentes
        (self._base, 
         self._adic_quartos, 
         self._adic_garagem, 
         self._desconto, 
         self._aluguel_mensal) = self._imovel.calcular_aluguel_mensal(self._cliente.tem_criancas)
 
        # Divisão exata da taxa contratual com distribuição contábil do resíduo de centavos
        self._lista_parcelas_taxa = self._calcular_lista_parcelas_taxa()
 
    def _calcular_lista_parcelas_taxa(self) -> list[Decimal]:
        """Divide R$ 2.000,00 em N parcelas sem perda ou ganho de centavos."""
        n = self._parcelas_taxa
        total_cents = int(self.TAXA_CONTRATUAL_TOTAL * 100) # 200000 centavos
        base_cents = total_cents // n
        remainder_cents = total_cents % n
 
        parcelas = []
        for i in range(n):
            cents = base_cents + (1 if i < remainder_cents else 0)
            parcelas.append((Decimal(cents) / Decimal(100)).quantize(Decimal("0.01")))
        return parcelas
 
    @property
    def cliente(self) -> Cliente:
        return self._cliente
 
    @property
    def imovel(self) -> Imovel:
        return self._imovel
 
    @property
    def parcelas_taxa(self) -> int:
        return self._parcelas_taxa
 
    @property
    def base(self) -> Decimal:
        return self._base
 
    @property
    def adic_quartos(self) -> Decimal:
        return self._adic_quartos
 
    @property
    def adic_garagem(self) -> Decimal:
        return self._adic_garagem
 
    @property
    def desconto(self) -> Decimal:
        return self._desconto
 
    @property
    def aluguel_mensal(self) -> Decimal:
        return self._aluguel_mensal
 
    @property
    def valor_primeira_parcela_taxa(self) -> Decimal:
        return self._lista_parcelas_taxa[0]
 
    @property
    def lista_parcelas_taxa(self) -> list[Decimal]:
        return self._lista_parcelas_taxa
 
    @property
    def total_primeiro_mes(self) -> Decimal:
        return self._aluguel_mensal + self.valor_primeira_parcela_taxa
 
    @property
    def total_previsto_12_meses(self) -> Decimal:
        return (self._aluguel_mensal * Decimal("12")) + self.TAXA_CONTRATUAL_TOTAL
 
    def obter_fluxo_12_meses(self) -> list[dict]:
        """Gera o detalhamento mensal para os 12 meses do contrato."""
        fluxo = []
        for mes in range(1, 13):
            idx = mes - 1
            parcela_devida = self._lista_parcelas_taxa[idx] if idx < self._parcelas_taxa else Decimal("0.00")
            total_mes = self._aluguel_mensal + parcela_devida
            fluxo.append({
                "mes": mes,
                "aluguel_mensal": self._aluguel_mensal,
                "parcela_taxa": parcela_devida,
                "total_mes": total_mes
            })
        return fluxo
